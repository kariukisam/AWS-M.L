from setuptools import setup

setup(name='gauss_bin_distr',
      version='1.1',
      description='Gaussian and Binomial distributions',
      packages=['gauss_bin_distr'],
      author = 'Kariuki Samuel',
      author_email = 'samuelkariuki544@gmail.com',
      zip_safe=False)
